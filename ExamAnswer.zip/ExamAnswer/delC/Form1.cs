﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace delC
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnKlockslag_Click(object sender, EventArgs e)
        {
            //deluppgift a:
            //getting input (hours and minuts) from textBoxes, performing type conversion
            //and placing them into variables 'hour' and 'minut'
            int hour = Convert.ToInt32(tbxTimme.Text);
            int minut = Convert.ToInt32(tbxMinut.Text);
            //Building a string using cancatenation and passing it into
            //textBox to show on the form

            //deluppgift c:
            //Avrundning av minuter och timmar
            // läs och förstå hur jag jobbar med division och modulus. Du behöver egentligen inte 
            // if-else eller loppar. 
            hour = hour + minut / 60;
            minut = minut % 60;
            hour = hour % 24;

            tbxKlockslag.Text = hour + ":" + minut;
        }

        private void btnNyttKlockslag_Click(object sender, EventArgs e)
        {
            // deluppgift b:
            int hour = Convert.ToInt32(tbxTimme.Text);
            int minut = Convert.ToInt32(tbxMinut.Text);

            //getting new time input (hours and minuts) from textBoxes, performing type conversion
            //and placing them into variables 'newHour' and 'newMinut'
            int newHour = Convert.ToInt32(tbxÖkaTimme.Text);
            int newMinut = Convert.ToInt32(tbxÖkaMinut.Text);

            //Öka tiden
            newHour = newHour + hour;
            newMinut = newMinut + minut;

            //deluppgift c:
            //Avrundning av minuter och timmar
            // läs och förstå hur jag jobbar med division och modulus. Du behöver egentligen inte 
            // if-else eller lopp. 

            newHour = newHour + newMinut / 60;
            newMinut = newMinut % 60;
            newHour = newHour % 24;


            //output
            tbxNyttKlockslag.Text = newHour + " : " + newMinut;
        }
    }
}
