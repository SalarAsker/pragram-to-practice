﻿namespace delAdelB
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.tbxNyttKlockslag = new System.Windows.Forms.TextBox();
            this.btnNyttKlockslag = new System.Windows.Forms.Button();
            this.tbxÖkaMinut = new System.Windows.Forms.TextBox();
            this.lblkolon = new System.Windows.Forms.Label();
            this.tbxÖkaTimme = new System.Windows.Forms.TextBox();
            this.lblökatiden = new System.Windows.Forms.Label();
            this.tbxKlockslag = new System.Windows.Forms.TextBox();
            this.btnKlockslag = new System.Windows.Forms.Button();
            this.tbxMinut = new System.Windows.Forms.TextBox();
            this.lblminut = new System.Windows.Forms.Label();
            this.tbxTimme = new System.Windows.Forms.TextBox();
            this.lblTimme = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(67, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(175, 20);
            this.label1.TabIndex = 37;
            this.label1.Text = "Del A och Del B lösning";
            // 
            // tbxNyttKlockslag
            // 
            this.tbxNyttKlockslag.Location = new System.Drawing.Point(132, 174);
            this.tbxNyttKlockslag.Name = "tbxNyttKlockslag";
            this.tbxNyttKlockslag.ReadOnly = true;
            this.tbxNyttKlockslag.Size = new System.Drawing.Size(150, 20);
            this.tbxNyttKlockslag.TabIndex = 36;
            // 
            // btnNyttKlockslag
            // 
            this.btnNyttKlockslag.Location = new System.Drawing.Point(16, 174);
            this.btnNyttKlockslag.Name = "btnNyttKlockslag";
            this.btnNyttKlockslag.Size = new System.Drawing.Size(95, 23);
            this.btnNyttKlockslag.TabIndex = 35;
            this.btnNyttKlockslag.Text = "Nytt klockslag ->";
            this.btnNyttKlockslag.UseVisualStyleBackColor = true;
            this.btnNyttKlockslag.Click += new System.EventHandler(this.btnNyttKlockslag_Click);
            // 
            // tbxÖkaMinut
            // 
            this.tbxÖkaMinut.Location = new System.Drawing.Point(221, 128);
            this.tbxÖkaMinut.Name = "tbxÖkaMinut";
            this.tbxÖkaMinut.Size = new System.Drawing.Size(61, 20);
            this.tbxÖkaMinut.TabIndex = 34;
            // 
            // lblkolon
            // 
            this.lblkolon.AutoSize = true;
            this.lblkolon.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblkolon.Location = new System.Drawing.Point(203, 131);
            this.lblkolon.Name = "lblkolon";
            this.lblkolon.Size = new System.Drawing.Size(11, 13);
            this.lblkolon.TabIndex = 33;
            this.lblkolon.Text = ":";
            // 
            // tbxÖkaTimme
            // 
            this.tbxÖkaTimme.Location = new System.Drawing.Point(136, 128);
            this.tbxÖkaTimme.Name = "tbxÖkaTimme";
            this.tbxÖkaTimme.Size = new System.Drawing.Size(61, 20);
            this.tbxÖkaTimme.TabIndex = 32;
            // 
            // lblökatiden
            // 
            this.lblökatiden.AutoSize = true;
            this.lblökatiden.Location = new System.Drawing.Point(13, 131);
            this.lblökatiden.Name = "lblökatiden";
            this.lblökatiden.Size = new System.Drawing.Size(117, 13);
            this.lblökatiden.TabIndex = 31;
            this.lblökatiden.Text = "Öka tiden med (tim:min)";
            // 
            // tbxKlockslag
            // 
            this.tbxKlockslag.Location = new System.Drawing.Point(132, 82);
            this.tbxKlockslag.Name = "tbxKlockslag";
            this.tbxKlockslag.ReadOnly = true;
            this.tbxKlockslag.Size = new System.Drawing.Size(150, 20);
            this.tbxKlockslag.TabIndex = 30;
            // 
            // btnKlockslag
            // 
            this.btnKlockslag.Location = new System.Drawing.Point(16, 82);
            this.btnKlockslag.Name = "btnKlockslag";
            this.btnKlockslag.Size = new System.Drawing.Size(95, 23);
            this.btnKlockslag.TabIndex = 29;
            this.btnKlockslag.Text = "Visa klockslag ->";
            this.btnKlockslag.UseVisualStyleBackColor = true;
            this.btnKlockslag.Click += new System.EventHandler(this.btnKlockslag_Click);
            // 
            // tbxMinut
            // 
            this.tbxMinut.Location = new System.Drawing.Point(221, 40);
            this.tbxMinut.Name = "tbxMinut";
            this.tbxMinut.Size = new System.Drawing.Size(61, 20);
            this.tbxMinut.TabIndex = 28;
            // 
            // lblminut
            // 
            this.lblminut.AutoSize = true;
            this.lblminut.Location = new System.Drawing.Point(157, 43);
            this.lblminut.Name = "lblminut";
            this.lblminut.Size = new System.Drawing.Size(63, 13);
            this.lblminut.TabIndex = 27;
            this.lblminut.Text = "Ange minut:";
            // 
            // tbxTimme
            // 
            this.tbxTimme.Location = new System.Drawing.Point(84, 40);
            this.tbxTimme.Name = "tbxTimme";
            this.tbxTimme.Size = new System.Drawing.Size(61, 20);
            this.tbxTimme.TabIndex = 26;
            // 
            // lblTimme
            // 
            this.lblTimme.AutoSize = true;
            this.lblTimme.Location = new System.Drawing.Point(13, 44);
            this.lblTimme.Name = "lblTimme";
            this.lblTimme.Size = new System.Drawing.Size(65, 13);
            this.lblTimme.TabIndex = 25;
            this.lblTimme.Text = "Ange timme:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(301, 217);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tbxNyttKlockslag);
            this.Controls.Add(this.btnNyttKlockslag);
            this.Controls.Add(this.tbxÖkaMinut);
            this.Controls.Add(this.lblkolon);
            this.Controls.Add(this.tbxÖkaTimme);
            this.Controls.Add(this.lblökatiden);
            this.Controls.Add(this.tbxKlockslag);
            this.Controls.Add(this.btnKlockslag);
            this.Controls.Add(this.tbxMinut);
            this.Controls.Add(this.lblminut);
            this.Controls.Add(this.tbxTimme);
            this.Controls.Add(this.lblTimme);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tbxNyttKlockslag;
        private System.Windows.Forms.Button btnNyttKlockslag;
        private System.Windows.Forms.TextBox tbxÖkaMinut;
        private System.Windows.Forms.Label lblkolon;
        private System.Windows.Forms.TextBox tbxÖkaTimme;
        private System.Windows.Forms.Label lblökatiden;
        private System.Windows.Forms.TextBox tbxKlockslag;
        private System.Windows.Forms.Button btnKlockslag;
        private System.Windows.Forms.TextBox tbxMinut;
        private System.Windows.Forms.Label lblminut;
        private System.Windows.Forms.TextBox tbxTimme;
        private System.Windows.Forms.Label lblTimme;
    }
}

