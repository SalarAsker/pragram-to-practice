﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace delAdelB
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnKlockslag_Click(object sender, EventArgs e)
        {
            //deluppgift a:
            //getting input (hours and minuts) from textBoxes, performing type conversion
            //and placing them into variables 'hour' and 'minut'
            int hour = Convert.ToInt32(tbxTimme.Text);
            int minut = Convert.ToInt32(tbxMinut.Text);
            //Building a string using cancatenation and passing it into
            //textBox to show on the form
            tbxKlockslag.Text = hour + ":" + minut;
        }

        private void btnNyttKlockslag_Click(object sender, EventArgs e)
        {
            //deluppgift b:
            int hour = Convert.ToInt32(tbxTimme.Text);
            int minut = Convert.ToInt32(tbxMinut.Text);

            //getting new time input (hours and minuts) from textBoxes, performing type conversion
            //and placing them into variables 'newHour' and 'newMinut'
            int newHour = Convert.ToInt32(tbxÖkaTimme.Text);
            int newMinut = Convert.ToInt32(tbxÖkaMinut.Text);


            //increasing time
            newHour = newHour + hour;
            newMinut = newMinut + minut;
            //output
            tbxNyttKlockslag.Text = newHour + " : " + newMinut;
        }
    }
}
