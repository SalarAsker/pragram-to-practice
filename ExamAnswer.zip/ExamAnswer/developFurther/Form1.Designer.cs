﻿namespace developFurther
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tbxNyttKlockslag = new System.Windows.Forms.TextBox();
            this.btnNyttKlockslag = new System.Windows.Forms.Button();
            this.tbxÖkaMinut = new System.Windows.Forms.TextBox();
            this.lblkolon = new System.Windows.Forms.Label();
            this.tbxÖkaTimme = new System.Windows.Forms.TextBox();
            this.lblökatiden = new System.Windows.Forms.Label();
            this.tbxKlockslag = new System.Windows.Forms.TextBox();
            this.btnKlockslag = new System.Windows.Forms.Button();
            this.tbxMinut = new System.Windows.Forms.TextBox();
            this.lblminut = new System.Windows.Forms.Label();
            this.tbxTimme = new System.Windows.Forms.TextBox();
            this.lblTimme = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.btnRensa = new System.Windows.Forms.Button();
            this.btnStang = new System.Windows.Forms.Button();
            this.pbKlocka = new System.Windows.Forms.PictureBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.pbKlocka)).BeginInit();
            this.SuspendLayout();
            // 
            // tbxNyttKlockslag
            // 
            this.tbxNyttKlockslag.Location = new System.Drawing.Point(504, 324);
            this.tbxNyttKlockslag.Name = "tbxNyttKlockslag";
            this.tbxNyttKlockslag.ReadOnly = true;
            this.tbxNyttKlockslag.Size = new System.Drawing.Size(150, 20);
            this.tbxNyttKlockslag.TabIndex = 61;
            // 
            // btnNyttKlockslag
            // 
            this.btnNyttKlockslag.Location = new System.Drawing.Point(388, 324);
            this.btnNyttKlockslag.Name = "btnNyttKlockslag";
            this.btnNyttKlockslag.Size = new System.Drawing.Size(95, 23);
            this.btnNyttKlockslag.TabIndex = 60;
            this.btnNyttKlockslag.Text = "Nytt klockslag ->";
            this.btnNyttKlockslag.UseVisualStyleBackColor = true;
            // 
            // tbxÖkaMinut
            // 
            this.tbxÖkaMinut.Location = new System.Drawing.Point(593, 296);
            this.tbxÖkaMinut.Name = "tbxÖkaMinut";
            this.tbxÖkaMinut.Size = new System.Drawing.Size(61, 20);
            this.tbxÖkaMinut.TabIndex = 59;
            // 
            // lblkolon
            // 
            this.lblkolon.AutoSize = true;
            this.lblkolon.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblkolon.Location = new System.Drawing.Point(575, 299);
            this.lblkolon.Name = "lblkolon";
            this.lblkolon.Size = new System.Drawing.Size(11, 13);
            this.lblkolon.TabIndex = 58;
            this.lblkolon.Text = ":";
            // 
            // tbxÖkaTimme
            // 
            this.tbxÖkaTimme.Location = new System.Drawing.Point(508, 296);
            this.tbxÖkaTimme.Name = "tbxÖkaTimme";
            this.tbxÖkaTimme.Size = new System.Drawing.Size(61, 20);
            this.tbxÖkaTimme.TabIndex = 57;
            // 
            // lblökatiden
            // 
            this.lblökatiden.AutoSize = true;
            this.lblökatiden.Location = new System.Drawing.Point(385, 299);
            this.lblökatiden.Name = "lblökatiden";
            this.lblökatiden.Size = new System.Drawing.Size(117, 13);
            this.lblökatiden.TabIndex = 56;
            this.lblökatiden.Text = "Öka tiden med (tim:min)";
            // 
            // tbxKlockslag
            // 
            this.tbxKlockslag.Location = new System.Drawing.Point(504, 267);
            this.tbxKlockslag.Name = "tbxKlockslag";
            this.tbxKlockslag.ReadOnly = true;
            this.tbxKlockslag.Size = new System.Drawing.Size(150, 20);
            this.tbxKlockslag.TabIndex = 55;
            // 
            // btnKlockslag
            // 
            this.btnKlockslag.Location = new System.Drawing.Point(388, 267);
            this.btnKlockslag.Name = "btnKlockslag";
            this.btnKlockslag.Size = new System.Drawing.Size(95, 23);
            this.btnKlockslag.TabIndex = 54;
            this.btnKlockslag.Text = "Visa klockslag ->";
            this.btnKlockslag.UseVisualStyleBackColor = true;
            // 
            // tbxMinut
            // 
            this.tbxMinut.Location = new System.Drawing.Point(593, 238);
            this.tbxMinut.Name = "tbxMinut";
            this.tbxMinut.Size = new System.Drawing.Size(61, 20);
            this.tbxMinut.TabIndex = 53;
            // 
            // lblminut
            // 
            this.lblminut.AutoSize = true;
            this.lblminut.Location = new System.Drawing.Point(529, 241);
            this.lblminut.Name = "lblminut";
            this.lblminut.Size = new System.Drawing.Size(63, 13);
            this.lblminut.TabIndex = 52;
            this.lblminut.Text = "Ange minut:";
            // 
            // tbxTimme
            // 
            this.tbxTimme.Location = new System.Drawing.Point(456, 238);
            this.tbxTimme.Name = "tbxTimme";
            this.tbxTimme.Size = new System.Drawing.Size(61, 20);
            this.tbxTimme.TabIndex = 51;
            // 
            // lblTimme
            // 
            this.lblTimme.AutoSize = true;
            this.lblTimme.Location = new System.Drawing.Point(385, 242);
            this.lblTimme.Name = "lblTimme";
            this.lblTimme.Size = new System.Drawing.Size(65, 13);
            this.lblTimme.TabIndex = 50;
            this.lblTimme.Text = "Ange timme:";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(45, 69);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(234, 32);
            this.textBox1.TabIndex = 63;
            this.textBox1.Text = "1. Utöka programmet genom att lägga även sekunder. ";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(45, 98);
            this.textBox2.Multiline = true;
            this.textBox2.Name = "textBox2";
            this.textBox2.ReadOnly = true;
            this.textBox2.Size = new System.Drawing.Size(234, 36);
            this.textBox2.TabIndex = 64;
            this.textBox2.Text = "2. En rensa knapp som rensar allt och den första texboxen får fokus.";
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(45, 132);
            this.textBox3.Multiline = true;
            this.textBox3.Name = "textBox3";
            this.textBox3.ReadOnly = true;
            this.textBox3.Size = new System.Drawing.Size(234, 30);
            this.textBox3.TabIndex = 65;
            this.textBox3.Text = "3. Lägg en Exit knapp som stänger applikation.";
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(45, 159);
            this.textBox4.Multiline = true;
            this.textBox4.Name = "textBox4";
            this.textBox4.ReadOnly = true;
            this.textBox4.Size = new System.Drawing.Size(234, 22);
            this.textBox4.TabIndex = 66;
            this.textBox4.Text = "4. Lägg någon bild på klockan i programmet. ";
            // 
            // btnRensa
            // 
            this.btnRensa.Location = new System.Drawing.Point(427, 357);
            this.btnRensa.Name = "btnRensa";
            this.btnRensa.Size = new System.Drawing.Size(75, 23);
            this.btnRensa.TabIndex = 67;
            this.btnRensa.Text = "Rensa";
            this.btnRensa.UseVisualStyleBackColor = true;
            this.btnRensa.Click += new System.EventHandler(this.btnRensa_Click);
            // 
            // btnStang
            // 
            this.btnStang.Location = new System.Drawing.Point(544, 357);
            this.btnStang.Name = "btnStang";
            this.btnStang.Size = new System.Drawing.Size(75, 23);
            this.btnStang.TabIndex = 68;
            this.btnStang.Text = "Stäng";
            this.btnStang.UseVisualStyleBackColor = true;
            this.btnStang.Click += new System.EventHandler(this.btnStang_Click);
            // 
            // pbKlocka
            // 
            this.pbKlocka.Location = new System.Drawing.Point(469, 132);
            this.pbKlocka.Name = "pbKlocka";
            this.pbKlocka.Size = new System.Drawing.Size(100, 89);
            this.pbKlocka.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbKlocka.TabIndex = 69;
            this.pbKlocka.TabStop = false;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(45, 178);
            this.textBox5.Multiline = true;
            this.textBox5.Name = "textBox5";
            this.textBox5.ReadOnly = true;
            this.textBox5.Size = new System.Drawing.Size(234, 22);
            this.textBox5.TabIndex = 70;
            this.textBox5.Text = "5. Fixa tab index";
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(45, 199);
            this.textBox6.Multiline = true;
            this.textBox6.Name = "textBox6";
            this.textBox6.ReadOnly = true;
            this.textBox6.Size = new System.Drawing.Size(234, 22);
            this.textBox6.TabIndex = 71;
            this.textBox6.Text = "6. Undersök form egenskap \'StartPositoin\'";
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(45, 221);
            this.textBox7.Multiline = true;
            this.textBox7.Name = "textBox7";
            this.textBox7.ReadOnly = true;
            this.textBox7.Size = new System.Drawing.Size(234, 33);
            this.textBox7.TabIndex = 72;
            this.textBox7.Text = "7. Undersök form egenskaper \'MinimizeBox\' och \'MaximizeBox\'";
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(45, 254);
            this.textBox8.Multiline = true;
            this.textBox8.Name = "textBox8";
            this.textBox8.ReadOnly = true;
            this.textBox8.Size = new System.Drawing.Size(234, 21);
            this.textBox8.TabIndex = 73;
            this.textBox8.Text = "8. Undersök form egenskap \' formBorderStyle \'";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(680, 386);
            this.Controls.Add(this.textBox8);
            this.Controls.Add(this.textBox7);
            this.Controls.Add(this.textBox6);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.pbKlocka);
            this.Controls.Add(this.btnStang);
            this.Controls.Add(this.btnRensa);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.tbxNyttKlockslag);
            this.Controls.Add(this.btnNyttKlockslag);
            this.Controls.Add(this.tbxÖkaMinut);
            this.Controls.Add(this.lblkolon);
            this.Controls.Add(this.tbxÖkaTimme);
            this.Controls.Add(this.lblökatiden);
            this.Controls.Add(this.tbxKlockslag);
            this.Controls.Add(this.btnKlockslag);
            this.Controls.Add(this.tbxMinut);
            this.Controls.Add(this.lblminut);
            this.Controls.Add(this.tbxTimme);
            this.Controls.Add(this.lblTimme);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pbKlocka)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox tbxNyttKlockslag;
        private System.Windows.Forms.Button btnNyttKlockslag;
        private System.Windows.Forms.TextBox tbxÖkaMinut;
        private System.Windows.Forms.Label lblkolon;
        private System.Windows.Forms.TextBox tbxÖkaTimme;
        private System.Windows.Forms.Label lblökatiden;
        private System.Windows.Forms.TextBox tbxKlockslag;
        private System.Windows.Forms.Button btnKlockslag;
        private System.Windows.Forms.TextBox tbxMinut;
        private System.Windows.Forms.Label lblminut;
        private System.Windows.Forms.TextBox tbxTimme;
        private System.Windows.Forms.Label lblTimme;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Button btnRensa;
        private System.Windows.Forms.Button btnStang;
        private System.Windows.Forms.PictureBox pbKlocka;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox8;
    }
}

