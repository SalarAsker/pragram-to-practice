﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace developFurther
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnRensa_Click(object sender, EventArgs e)
        {
            tbxTimme.Text = "";
            tbxMinut.Text = "";
            tbxKlockslag.Text = "";
            tbxÖkaTimme.Text = "";
            tbxÖkaMinut.Text = "";
            tbxNyttKlockslag.Text = "";
            tbxTimme.Focus();
        }

        private void btnStang_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            pbKlocka.Image = Image.FromFile("clock.gif");
        }
    }
}
