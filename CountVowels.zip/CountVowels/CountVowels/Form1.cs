﻿/*
 
A program that counts the vowels in a word that user enters in a textbox. 
If user enter elephant the program will display 3  

Author
Salar Asker Zada
 
  */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CountVowels
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCheck_Click(object sender, EventArgs e)
        {
            string word = tbxWord.Text;
            char[] vowels = { 'a', 'e', 'i', 'o', 'u' };
            int count = 0;

            foreach (char character in word)//every character in word
            {
                for (int i = 0; i < 5; i++)//compares with vowels
                {
                    if (character == vowels[i])
                        count++;
                }
            }
            //Another solution
            /*
            foreach (char character in word)//every character in word
            {
                 if (vowels.Contains(character))
                        count++;
            }
            */
                                          
            lblCount.Text = count.ToString();
        }
    }
}
