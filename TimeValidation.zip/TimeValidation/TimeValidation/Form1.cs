﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TimeValidation
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCheck_Click(object sender, EventArgs e)
        {
            string time = tbxTIme.Text;

            if(string.IsNullOrEmpty(time) || string.IsNullOrWhiteSpace(time) || time[2]!=':')
            {
                MessageBox.Show("Invalid time");
            }
            else
            {
                string[] hourMinut = time.Split(':');
                int hour = int.Parse(hourMinut[0]);
                int minut =int.Parse( hourMinut[1]);

                if(isHourValid(hour) && isminutValid(minut))
                {
                    lblResult.Text = "OK";
                }
                else
                {
                    lblResult.Text = "NOT OK";
                }
            }

        }
        //class scope
        //checking valid hours range
        private static bool isHourValid(int hour)
        {
            return hour >=0 && hour<=23;
        }
        //checking valid minuts range
        private static bool isminutValid(int minut)
        {
            return minut >=0 && minut <=59;
        }
    }
}
